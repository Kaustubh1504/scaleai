"""Supplier catalog merge."""
