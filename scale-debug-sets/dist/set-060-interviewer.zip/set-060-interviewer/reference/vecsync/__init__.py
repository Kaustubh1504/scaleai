"""Async embedding backfill client."""
